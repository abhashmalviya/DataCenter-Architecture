#!/usr/bin/env python
 
from mininet.net import Mininet
from mininet.node import Controller, RemoteController
from mininet.cli import CLI
from mininet.log import setLogLevel, info
from mininet.link import Link, Intf, TCLink
from mininet.topo import Topo
from mininet.util import dumpNodeConnections
import logging
import os 
 
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger( __name__ )
 
class HugeTopo(Topo):
    #logger.debug("Class HugeTopo")
    CoreSwitchList = []
    AggSwitchList = []
    EAggSwitchList = []
    EdgeSwitchList = []
    HostList = []
    CHList = []

    #iNUMBER = 0
    def __init__(self):
        #logger.debug("Class HugeTopo init")
        #iNUMBER = 4
        
        #self.iNUMBER = iNUMBER
        self.iCoreLayerSwitch = 2
        self.EAggLayerSwitch = 8
        #self.iAggLayerSwitch = 4
        self.iEdgeLayerSwitch = 4
        self.iHost = 16
        self.iCHost = 2

        #Init Topo
        Topo.__init__(self)
 
    def createTopo(self):    
     #   logger.debug("Start create Core Layer Swich")
        self.createCoreLayerSwitch(self.iCoreLayerSwitch)
	self.createEAggLayerSwitch(self.EAggLayerSwitch)
      #  logger.debug("Start create Agg Layer Swich ")
        #self.createAggLayerSwitch(self.iAggLayerSwitch)
       # logger.debug("Start create Edge Layer Swich ")
        self.createEdgeLayerSwitch(self.iEdgeLayerSwitch)
       # logger.debug("Start create Host")
        self.createHost(self.iHost)
	self.createCHost(self.iCHost)
 
    """
    Create Switch and Host
    """
 
    def createCoreLayerSwitch(self,N):
        #logger.debug("Create Core Layer")
        for x in range(0,self.iCoreLayerSwitch):
            PREFIX = "C"
            self.CoreSwitchList.append(self.addSwitch(PREFIX + str(x)))

    def createEAggLayerSwitch(self,N):
	for x in range(0, self.EAggLayerSwitch):
	   PREFIX = "S_1AL"
	   self.EAggSwitchList.append(self.addSwitch(PREFIX + str(x)))
 
    #def createAggLayerSwitch(self,N):
        #logger.debug( "Create Agg Layer")
        #for x in range(0,self.iAggLayerSwitch):
            #PREFIX = "A2"
            #self.AggSwitchList.append(self.addSwitch(PREFIX + str(x)))
 
    def createEdgeLayerSwitch(self,N):
        #logger.debug("Create Edge Layer")
        for x in range(0,self.iEdgeLayerSwitch ):
            PREFIX = "TR"
            self.EdgeSwitchList.append(self.addSwitch(PREFIX + str(x)))
    
    def createHost(self,N):
        #logger.debug("Create Host")
        for x in range(0,self.iHost):
            PREFIX = "H"
            self.HostList.append(self.addHost(PREFIX + str(x)))

    def createCHost(self,N):
        #logger.debug("Create Host")
        for x in range(1,self.iCHost):
            PREFIX = "LB"
            self.CHList.append(self.addHost(PREFIX + str(x)))
	    #print "6"
   
 
 
    """
    Create Link 
    """
    def cLink1(self):
    	self.addLink(self.CoreSwitchList[1], self.CHList[0])
        #logger.debug("Create Core to EAgg")
        for x in range(0,2):
	   print " Setting up connection between Core and Aggregate Switches "
	   self.addLink(self.CoreSwitchList[x], self.EAggSwitchList[x])
           self.addLink(self.CoreSwitchList[x], self.EAggSwitchList[x+2])
           self.addLink(self.CoreSwitchList[x], self.EAggSwitchList[x+4])
           self.addLink(self.CoreSwitchList[x], self.EAggSwitchList[x+6])
    
    def cLink2(self):
	print " Setting up connection between Aggregate and TOR Switches"
	for y in range(0,1):
	    self.addLink(self.EAggSwitchList[y],self.EdgeSwitchList[y])
	    self.addLink(self.EAggSwitchList[y],self.EdgeSwitchList[y+1])
            self.addLink(self.EAggSwitchList[y+1],self.EdgeSwitchList[y])
	    self.addLink(self.EAggSwitchList[y+1],self.EdgeSwitchList[y+1])
	    self.addLink(self.EAggSwitchList[y+2],self.EdgeSwitchList[y])
	    self.addLink(self.EAggSwitchList[y+2],self.EdgeSwitchList[y+1])
            self.addLink(self.EAggSwitchList[y+3],self.EdgeSwitchList[y])
	    self.addLink(self.EAggSwitchList[y+3],self.EdgeSwitchList[y+1])
	for y in range(4,5):
	    self.addLink(self.EAggSwitchList[y],self.EdgeSwitchList[2])
	    self.addLink(self.EAggSwitchList[y],self.EdgeSwitchList[3])
            self.addLink(self.EAggSwitchList[y+1],self.EdgeSwitchList[2])
	    self.addLink(self.EAggSwitchList[y+1],self.EdgeSwitchList[3])
	    self.addLink(self.EAggSwitchList[y+2],self.EdgeSwitchList[2])
	    self.addLink(self.EAggSwitchList[y+2],self.EdgeSwitchList[3])
            self.addLink(self.EAggSwitchList[y+3],self.EdgeSwitchList[2])
	    self.addLink(self.EAggSwitchList[y+3],self.EdgeSwitchList[3])

	 #logger.debug("Create iAgg to Edge")
    #def cLink3(self):
	#for z in range (0,self.iAggLayerSwitch,2):
         #   self.addLink(self.AggSwitchList[z], self.EdgeSwitchList[z])
          #  self.addLink(self.AggSwitchList[z], self.EdgeSwitchList[z+1])
           # self.addLink(self.AggSwitchList[z + 1], self.EdgeSwitchList[z])
	    #self.addLink(self.AggSwitchList[z + 1], self.EdgeSwitchList[z+1])
       
    def cLink4(self):	
        #logger.debug("Create Edge to Host")
	print " Setting up connection between TOR and Host "
        for r in range(0,4):
            ## limit = 2 * x + 1 
            self.addLink(self.EdgeSwitchList[r], self.HostList[(4 * r) + 0])
            self.addLink(self.EdgeSwitchList[r], self.HostList[(4 * r) + 1])
	    self.addLink(self.EdgeSwitchList[r], self.HostList[(4 * r) + 2])
	    self.addLink(self.EdgeSwitchList[r], self.HostList[(4 * r) + 3])
	
 
def enableSTP1():

    for x in range(0,2):
        cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("C" + str(x))
        os.system(cmd)
        print cmd 

def enableSTP2(): 
    for x in range(0,8):
        cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("S_1AL" + str(x))
        os.system(cmd)  
        print cmd 

#def enableSTP3():        
 #   for x in range(0,4):
#	cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("A2" + str(x))
 #       os.system(cmd)
  #      print cmd

def enableSTP4():   
    for x in range(0,4):
	cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("TR" + str(x))
        os.system(cmd)
        print cmd


#def pingTest(net):
#    logger.debug("Start Test all network")
#    net.pingAll()

def createTopo():
    #logging.debug("LV1 Create HugeTopo")
    topo = HugeTopo()
    topo.createTopo() 
    topo.cLink1() 
    topo.cLink2()
    #topo.cLink3()
    topo.cLink4()      

    #logging.debug("LV1 Start Mininet")
    CONTROLLER_IP = "127.0.0.1"
    CONTROLLER_PORT = 6633
    net = Mininet(topo=topo, link=TCLink)
    net.addController( 'controller',ip=CONTROLLER_IP,port=CONTROLLER_PORT)
    
    net.start()
 
    #logger.debug("LV1 dumpNode")
    print "Enabling STP"
    enableSTP1()
    enableSTP2()
   # enableSTP3()
    enableSTP4()	
    dumpNodeConnections(net.hosts)
    
    #pingTest(net)
    #iperfTest(net, topo)
    
 
    CLI(net)
    #net.stop()





if __name__ == '__main__':
    setLogLevel('info')
    if os.getuid() != 0:
        logger.debug("You are NOT root")
    elif os.getuid() == 0:
        createTopo()

