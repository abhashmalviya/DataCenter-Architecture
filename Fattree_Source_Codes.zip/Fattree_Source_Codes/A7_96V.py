#!/usr/bin/env python
 
from mininet.net import Mininet
from mininet.node import Controller, RemoteController
from mininet.cli import CLI
from mininet.log import setLogLevel, info
from mininet.link import Link, Intf, TCLink
from mininet.topo import Topo
from mininet.util import dumpNodeConnections
import logging
import os 
 
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger( __name__ )
 
class HugeTopo(Topo):
    #logger.debug("Class HugeTopo")
    CoreSwitchList = []
    EAggSwitchList = []
    AggSwitchList = []
    Nswitch = []
    EdgeSwitchList = []
    HostList = []
    CHList = []

    #iNUMBER = 0
    def __init__(self):
        #logger.debug("Class HugeTopo init")
        #iNUMBER = 4
        
        #self.iNUMBER = iNUMBER
        self.iCoreLayerSwitch = 12
        self.EAggLayerSwitch = 14
        self.iAggLayerSwitch = 14
	self.switch = 14
        self.iEdgeLayerSwitch = 28
        self.iHost = 98
	self.iCHost = 2
    
        #Init Topo
        Topo.__init__(self)
 
    def createTopo(self):    
     #   logger.debug("Start create Core Layer Swich")
        self.createCoreLayerSwitch(self.iCoreLayerSwitch)
	self.createEAggLayerSwitch(self.EAggLayerSwitch)
      #  logger.debug("Start create Agg Layer Swich ")
        self.createAggLayerSwitch(self.iAggLayerSwitch)
	self.createNswitch(self.switch)
       # logger.debug("Start create Edge Layer Swich ")
        self.createEdgeLayerSwitch(self.iEdgeLayerSwitch)
       # logger.debug("Start create Host")
        self.createHost(self.iHost)
	self.createCHost(self.iCHost)

    """
    Create Switch and Host
    """
 
    def createCoreLayerSwitch(self,N):
        #logger.debug("Create Core Layer")
        for x in range(0,self.iCoreLayerSwitch):
            PREFIX = "C"
            self.CoreSwitchList.append(self.addSwitch(PREFIX + str(x)))

    def createEAggLayerSwitch(self,N): #Upper Aggregate Layer
	for x in range(0, self.EAggLayerSwitch):
	   PREFIX = "S_1AL"
	   self.EAggSwitchList.append(self.addSwitch(PREFIX + str(x)))
 
    def createAggLayerSwitch(self,N): # Middle Aggregate Layer
        #logger.debug( "Create Agg Layer")
        for x in range(0,self.iAggLayerSwitch):
            PREFIX = "S_2AL"
            self.AggSwitchList.append(self.addSwitch(PREFIX + str(x)))
    
    def createNswitch(self,N): # Lower Aggregate Layer
	for x in range(0,self.switch):
	    PREFIX = "S_3AL"
	    self.Nswitch.append(self.addSwitch(PREFIX + str(x)))

 
    def createEdgeLayerSwitch(self,N):
        #logger.debug("Create Edge Layer")  #Top of the layer
        for x in range(0,self.iEdgeLayerSwitch ):
            PREFIX = "TR"
            self.EdgeSwitchList.append(self.addSwitch(PREFIX + str(x)))
    
    def createHost(self,N):
        #logger.debug("Create Host")
        for x in range(0,self.iHost):
            PREFIX = "H"
            self.HostList.append(self.addHost(PREFIX + str(x)))

    def createCHost(self,N):
        #logger.debug("Create Host")
        for x in range(1,self.iCHost):
            PREFIX = "LB"
            self.CHList.append(self.addHost(PREFIX + str(x)))
	    #print "6"
 
 
    """
    Create Link 
    """
    def cLink1(self):
	self.addLink(self.CoreSwitchList[1], self.CHList[0])

        #logger.debug("Create Core to EAgg")
        for x in range(0,6):
	    for y in range(0,14,2):
	        self.addLink(self.CoreSwitchList[x], self.EAggSwitchList[y])
        for x in range(6,12):
	    for y in range(1,14,2):
	        self.addLink(self.CoreSwitchList[x], self.EAggSwitchList[y])
           
           
           
           
    
    def cLink2(self):
	for y in range(0,14,2):
            self.addLink(self.EAggSwitchList[y],self.AggSwitchList[y])
	
	    self.addLink(self.EAggSwitchList[y],self.AggSwitchList[y+1])
	
	    self.addLink(self.EAggSwitchList[y+1],self.AggSwitchList[y])
	
	    self.addLink(self.EAggSwitchList[y+1],self.AggSwitchList[y+1])
	    
	    

	 #logger.debug("Create iAgg to Edge")
    def cLink3(self):
	for y in range(0,14,2):
            self.addLink(self.AggSwitchList[y],self.Nswitch[y])
	
	    self.addLink(self.AggSwitchList[y],self.Nswitch[y+1])
	
	    self.addLink(self.AggSwitchList[y+1],self.Nswitch[y])
	
	    self.addLink(self.AggSwitchList[y+1],self.Nswitch[y+1])
    
    def cLink4(self):
	for y in range(0,2):
	    for x in range (0,4):
                self.addLink(self.Nswitch[y],self.EdgeSwitchList[x])
	
	for y in range(2,4):
	    for x in range (4,8):
                self.addLink(self.Nswitch[y],self.EdgeSwitchList[x])

	for y in range(4,6):
	    for x in range (8,12):
                self.addLink(self.Nswitch[y],self.EdgeSwitchList[x])

	for y in range(6,8):
	    for x in range (12,16):
                self.addLink(self.Nswitch[y],self.EdgeSwitchList[x])

	for y in range(8,10):
	    for x in range (16,20):
                self.addLink(self.Nswitch[y],self.EdgeSwitchList[x])

	for y in range(10,12):
	    for x in range (20,24):
                self.addLink(self.Nswitch[y],self.EdgeSwitchList[x])

	for y in range(12,14):
	    for x in range (24,28):
                self.addLink(self.Nswitch[y],self.EdgeSwitchList[x])
	
	
	
	
	
	
	
	        
       
    def cLink5(self):	
        #logger.debug("Create Edge to Host")
        for r in range(1,2):
            self.addLink(self.EdgeSwitchList[0], self.HostList[(0) ])
            self.addLink(self.EdgeSwitchList[0], self.HostList[1])
	    self.addLink(self.EdgeSwitchList[0], self.HostList[(2)])
            self.addLink(self.EdgeSwitchList[r], self.HostList[(2 * r) + 1])
	    self.addLink(self.EdgeSwitchList[r], self.HostList[(2 * r) + 2])
            self.addLink(self.EdgeSwitchList[r], self.HostList[(2 * r) + 3])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(2 * r)+ 4])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(2 * r) + 5])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(2 * r) +6])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(2 * r) + 7])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(2 * r) + 8])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(2 * r) + 9])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(2 * r) + 10])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(2 * r) + 11])
	for r in range(4,5):
	    self.addLink(self.EdgeSwitchList[r], self.HostList[(2 * r) + 6])
	    self.addLink(self.EdgeSwitchList[r], self.HostList[(2 * r) + 7])
            self.addLink(self.EdgeSwitchList[r], self.HostList[(2 * r) + 8])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(2 * r)+ 9])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(2 * r) + 10])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(2 * r) +11])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(2 * r) + 12])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(2 * r) + 13])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(2 * r) + 14])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(2 * r) + 15])
            self.addLink(self.EdgeSwitchList[r+3], self.HostList[(2 * r) + 16])
	    self.addLink(self.EdgeSwitchList[r+3], self.HostList[(2 * r) + 17])
            self.addLink(self.EdgeSwitchList[r+3], self.HostList[(2 * r) + 18])
            self.addLink(self.EdgeSwitchList[r+3], self.HostList[(2 * r) + 19])
	
	for r in range(8,9):
	    self.addLink(self.EdgeSwitchList[r], self.HostList[(3 * r) + 4])
	    self.addLink(self.EdgeSwitchList[r], self.HostList[(3 * r) + 5])
            self.addLink(self.EdgeSwitchList[r], self.HostList[(3 * r) + 6])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(3 * r)+ 7])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(3 * r) + 8])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(3 * r) +9])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(3 * r) + 10])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(3 * r) + 11])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(3 * r) + 12])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(3 * r) + 13])
            self.addLink(self.EdgeSwitchList[r+3], self.HostList[(3 * r) + 14])
	    self.addLink(self.EdgeSwitchList[r+3], self.HostList[(3 * r) + 15])
            self.addLink(self.EdgeSwitchList[r+3], self.HostList[(3 * r) + 16])
            self.addLink(self.EdgeSwitchList[r+3], self.HostList[(3 * r) + 17])
	
	for r in range(12,13):
	    self.addLink(self.EdgeSwitchList[r], self.HostList[(3 * r) + 6])
	    self.addLink(self.EdgeSwitchList[r], self.HostList[(3 * r) + 7])
            self.addLink(self.EdgeSwitchList[r], self.HostList[(3 * r) + 8])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(3 * r)+ 9])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(3 * r) + 10])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(3 * r) +11])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(3 * r) + 12])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(3 * r) + 13])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(3 * r) + 14])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(3 * r) + 15])
            self.addLink(self.EdgeSwitchList[r+3], self.HostList[(3 * r) + 16])
	    self.addLink(self.EdgeSwitchList[r+3], self.HostList[(3 * r) + 17])
            self.addLink(self.EdgeSwitchList[r+3], self.HostList[(3 * r) + 18])
            self.addLink(self.EdgeSwitchList[r+3], self.HostList[(3 * r) + 19])

	
	for r in range(16,17):
	    self.addLink(self.EdgeSwitchList[r], self.HostList[(3 * r) + 8])
	    self.addLink(self.EdgeSwitchList[r], self.HostList[(3 * r) + 9])
            self.addLink(self.EdgeSwitchList[r], self.HostList[(3 * r) + 10])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(3 * r)+ 11])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(3 * r) + 12])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(3 * r) +13])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(3 * r) + 14])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(3 * r) + 15])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(3 * r) + 16])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(3 * r) + 17])
            self.addLink(self.EdgeSwitchList[r+3], self.HostList[(3 * r) + 18])
	    self.addLink(self.EdgeSwitchList[r+3], self.HostList[(3 * r) + 19])
            self.addLink(self.EdgeSwitchList[r+3], self.HostList[(3 * r) + 20])
            self.addLink(self.EdgeSwitchList[r+3], self.HostList[(3 * r) + 21])
	
	for r in range(20,21):
	    self.addLink(self.EdgeSwitchList[r], self.HostList[(3 * r) + 10])
	    self.addLink(self.EdgeSwitchList[r], self.HostList[(3 * r) + 11])
            self.addLink(self.EdgeSwitchList[r], self.HostList[(3 * r) + 12])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(3 * r)+ 13])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(3 * r) + 14])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(3 * r) +15])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(3 * r) + 16])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(3 * r) + 17])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(3 * r) + 18])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(3 * r) + 19])
            self.addLink(self.EdgeSwitchList[r+3], self.HostList[(3 * r) + 20])
	    self.addLink(self.EdgeSwitchList[r+3], self.HostList[(3 * r) + 21])
            self.addLink(self.EdgeSwitchList[r+3], self.HostList[(3 * r) + 22])
            self.addLink(self.EdgeSwitchList[r+3], self.HostList[(3 * r) + 23])

	
	for r in range(24,25):
	    self.addLink(self.EdgeSwitchList[r], self.HostList[(3 * r) + 12])
	    self.addLink(self.EdgeSwitchList[r], self.HostList[(3 * r) + 13])
            self.addLink(self.EdgeSwitchList[r], self.HostList[(3 * r) + 14])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(3 * r)+ 15])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(3 * r) + 16])
            self.addLink(self.EdgeSwitchList[r+1], self.HostList[(3 * r) +17])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(3 * r) +18])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(3 * r) + 19])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(3 * r) + 20])
            self.addLink(self.EdgeSwitchList[r+2], self.HostList[(3 * r) + 21])
            self.addLink(self.EdgeSwitchList[r+3], self.HostList[(3 * r) + 22])
	    self.addLink(self.EdgeSwitchList[r+3], self.HostList[(3 * r) + 23])
            self.addLink(self.EdgeSwitchList[r+3], self.HostList[(3 * r) + 24])
            self.addLink(self.EdgeSwitchList[r+3], self.HostList[(3 * r) + 25])







def enableSTP1():

    for x in range(0,12):
        cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("C" + str(x))
        os.system(cmd)
        print cmd 

def enableSTP2(): 
    for x in range(0,14):
        cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("S_1AL" + str(x))
        os.system(cmd)  
        print cmd 

def enableSTP3():        
    for x in range(0,14):
	cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("S_2AL" + str(x))
        os.system(cmd)
        print cmd

def enableSTP4():        
    for x in range(0,14):
	cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("S_3AL" + str(x))
        os.system(cmd)
        print cmd

def enableSTP5():   
    for x in range(0,28):
	cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("TR" + str(x))
        os.system(cmd)
        print cmd


#def pingTest(net):
#    logger.debug("Start Test all network")
#    net.pingAll()

def createTopo():
    #logging.debug("LV1 Create HugeTopo")
    topo = HugeTopo()
    topo.createTopo() 
    topo.cLink1() 
    topo.cLink2()
    topo.cLink3()
    topo.cLink4()
    topo.cLink5()      
    #logging.debug("LV1 Start Mininet")
    CONTROLLER_IP = "127.0.0.1"
    CONTROLLER_PORT = 6633
    net = Mininet(topo=topo, link=TCLink)
    net.addController( 'controller',ip=CONTROLLER_IP,port=CONTROLLER_PORT)
    
    net.start()
 
    #logger.debug("LV1 dumpNode")
    enableSTP1()
    enableSTP2()
    enableSTP3()
    enableSTP4()
    enableSTP5()	
    dumpNodeConnections(net.hosts)
    
    #pingTest(net)
    #iperfTest(net, topo)
    
 
    CLI(net)
    #net.stop()





if __name__ == '__main__':
    setLogLevel('info')
    if os.getuid() != 0:
        logger.debug("You are NOT root")
    elif os.getuid() == 0:
        createTopo()

