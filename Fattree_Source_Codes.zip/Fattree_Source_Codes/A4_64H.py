#!/usr/bin/env python
 
from mininet.net import Mininet
from mininet.node import Controller, RemoteController
from mininet.cli import CLI
from mininet.log import setLogLevel, info
from mininet.link import Link, Intf, TCLink
from mininet.topo import Topo
from mininet.util import dumpNodeConnections
import logging
import os 
 
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger( __name__ )
 
class HugeTopo(Topo):
    #logger.debug("Class HugeTopo")
    CoreSwitchList = []
    EAggSwitchList = []
    AggSwitchList = []
    EdgeSwitchList = []
    HostList = []
    CHList = []

    #iNUMBER = 0
    def __init__(self):
        #logger.debug("Class HugeTopo init")
        #iNUMBER = 4
        
        #self.iNUMBER = iNUMBER
        self.iCoreLayerSwitch = 16
        self.EAggLayerSwitch = 32
        self.iEdgeLayerSwitch = 32
        self.iHost = 64
	self.iCHost = 2
    
        #Init Topo
        Topo.__init__(self)
 
    def createTopo(self): 
        self.createCoreLayerSwitch(self.iCoreLayerSwitch)

    def createCoreLayerSwitch(self,N):
        for x in range(0,self.iCoreLayerSwitch):
            PREFIX = "C"
            self.CoreSwitchList.append(self.addSwitch(PREFIX + str(x)))

        self.createEAggLayerSwitch(self.EAggLayerSwitch)

    def createEAggLayerSwitch(self,N):
        for x in range(0, self.EAggLayerSwitch):
	   PREFIX = "S_1AL"
	   self.EAggSwitchList.append(self.addSwitch(PREFIX + str(x)))
       
    
        self.createEdgeLayerSwitch(self.iEdgeLayerSwitch)

    def createEdgeLayerSwitch(self,N):
	for x in range(0,self.iEdgeLayerSwitch ):
            PREFIX = "TR"
            self.EdgeSwitchList.append(self.addSwitch(PREFIX + str(x)))

        self.createHost(self.iHost)

    def createHost(self,N):
        for x in range(0,self.iHost):
            PREFIX = "H"
            self.HostList.append(self.addHost(PREFIX + str(x)))

	self.createCHost(self.iCHost)

    def createCHost(self,N):
        for x in range(1,self.iCHost):
            PREFIX = "LB"
            self.CHList.append(self.addHost(PREFIX + str(x)))

   
	
    """
    Create Link 
    """
    def cLink1(self):
	self.addLink(self.CoreSwitchList[15], self.CHList[0])

        for x in range(0,4):
	    for y in range(0,16,4):
	        self.addLink(self.CoreSwitchList[x], self.EAggSwitchList[y])
	    for y in range(16,32,4):	
                self.addLink(self.CoreSwitchList[x], self.EAggSwitchList[y])	

	for x in range(4,8):
    	    for y in range(1,16,4):
	        self.addLink(self.CoreSwitchList[x], self.EAggSwitchList[y])
	    for y in range(17,32,4):	
                self.addLink(self.CoreSwitchList[x], self.EAggSwitchList[y])	


	for x in range(8,12):
    	    for y in range(2,16,4):
	        self.addLink(self.CoreSwitchList[x], self.EAggSwitchList[y])
	    for y in range(18,32,4):	
                self.addLink(self.CoreSwitchList[x], self.EAggSwitchList[y])
	


	for x in range(12,16):
    	    for y in range(3,16,4):
	        self.addLink(self.CoreSwitchList[x], self.EAggSwitchList[y])
	    for y in range(19,32,4):	
                self.addLink(self.CoreSwitchList[x], self.EAggSwitchList[y])	


    
    
    def cLink2(self):
	for x in range(0,4):
	    for y in range(0,4):
		self.addLink(self.EAggSwitchList[x],self.EdgeSwitchList[y])
	
	for x in range(4,8):
	    for y in range(4,8):
		self.addLink(self.EAggSwitchList[x],self.EdgeSwitchList[y])   
	
	for x in range(8,12):
	    for y in range(8,12):
		self.addLink(self.EAggSwitchList[x],self.EdgeSwitchList[y])
	
	for x in range(12,16):
	    for y in range(12,16):
		self.addLink(self.EAggSwitchList[x],self.EdgeSwitchList[y]) 
        
	for x in range(16,20):
	    for y in range(16,20):
		self.addLink(self.EAggSwitchList[x],self.EdgeSwitchList[y])
        
	for x in range(20,24):
	    for y in range(20,24):
		self.addLink(self.EAggSwitchList[x],self.EdgeSwitchList[y])
        
	for x in range(24,28):
	    for y in range(24,28):
		self.addLink(self.EAggSwitchList[x],self.EdgeSwitchList[y])
	
	for x in range(28,32):
	    for y in range(28,32):
		self.addLink(self.EAggSwitchList[x],self.EdgeSwitchList[y])
    
    def cLink4(self):	
        
        for r in range(0,16):
           
            self.addLink(self.EdgeSwitchList[r], self.HostList[(4 * r) + 0])
            self.addLink(self.EdgeSwitchList[r], self.HostList[(4 * r) + 1])
	    self.addLink(self.EdgeSwitchList[r], self.HostList[(4 * r) + 2])
	    self.addLink(self.EdgeSwitchList[r], self.HostList[(4 * r) + 3])
	
 
def enableSTP1():

    for x in range(0,16):
        cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("C" + str(x))
        os.system(cmd)
        print cmd 

def enableSTP2(): 
    for x in range(0,32):
        cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("S_1AL" + str(x))
        os.system(cmd)  
        print cmd 



def enableSTP4():   
    for x in range(0,32):
	cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("TR" + str(x))
        os.system(cmd)
        print cmd


#def pingTest(net):
#    logger.debug("Start Test all network")
#    net.pingAll()

def createTopo():
    #logging.debug("LV1 Create HugeTopo")
    topo = HugeTopo()
    topo.createTopo() 
    topo.cLink1() 
    topo.cLink2()
    
    topo.cLink4()      
    #logging.debug("LV1 Start Mininet")
    CONTROLLER_IP = "127.0.0.1"
    CONTROLLER_PORT = 6633
    net = Mininet(topo=topo, link=TCLink)
    net.addController( 'controller',ip=CONTROLLER_IP,port=CONTROLLER_PORT)
    
    net.start()
 
    #logger.debug("LV1 dumpNode")
    enableSTP1()
    enableSTP2()
    
    enableSTP4()	
    dumpNodeConnections(net.hosts)
    
    #pingTest(net)
    #iperfTest(net, topo)
    
 
    CLI(net)
    #net.stop()





if __name__ == '__main__':
    setLogLevel('info')
    if os.getuid() != 0:
        logger.debug("You are NOT root")
    elif os.getuid() == 0:
        createTopo()

