from mininet.net import Mininet
from mininet.node import Controller, RemoteController
from mininet.cli import CLI
from mininet.log import setLogLevel, info
from mininet.link import Link, Intf, TCLink
from mininet.topo import Topo
from mininet.util import dumpNodeConnections
import logging
import os 


logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger( __name__ )

class MultiTopo(Topo):
	CoreSwitchList = []
	A_AggSwitchList = []
	B_AggSwitchList = []	
	AggSwitchList = []
	TORSwitchList = []
	HostList = []
	ExList = []
	
	def __init__(self):
		self.iCoreLayerSwitch = 4
        	self.A_AggLayerSwitch = 16
		self.B_AggLayerSwitch = 16
        	self.iAggLayerSwitch = 16
        	self.iEdgeLayerSwitch = 32
        	self.iHost = 64
		self.extra = 1

		Topo.__init__(self)

	def createTopo(self):    
     
        	self.createCoreLayerSwitch(self.iCoreLayerSwitch)
		self.createAAggLayerSwitch(self.A_AggLayerSwitch)
		self.createBAggLayerSwitch(self.B_AggLayerSwitch)
      #  logger.debug("Start create Agg Layer Swich ")
        	self.createAggLayerSwitch(self.iAggLayerSwitch)
       # logger.debug("Start create Edge Layer Swich ")
        	self.createEdgeLayerSwitch(self.iEdgeLayerSwitch)
       # logger.debug("Start create Host")
        	self.createHost(self.iHost)
		self.createExtra(self.extra)

	def createCoreLayerSwitch(self,N):
        #logger.debug("Create Core Layer")
        	for x in range(0,self.iCoreLayerSwitch):
            		PREFIX = "CORE"
            		if x >= int(10):
                		PREFIX = "CORE"
            		self.CoreSwitchList.append(self.addSwitch(PREFIX + str(x)))

    	def createAAggLayerSwitch(self,N):
		for x in range(0, self.A_AggLayerSwitch):
	   		PREFIX = "S_Agg3"
	   		if x >= int(10):
	       			PREFIX = "S_Agg3"
	  		self.A_AggSwitchList.append(self.addSwitch(PREFIX + str(x)))

	def createBAggLayerSwitch(self,N):
		for x in range(0, self.B_AggLayerSwitch):
	   		PREFIX = "S_Agg2"
	   		if x >= int(10):
	       			PREFIX = "S_Agg2"
	  		self.B_AggSwitchList.append(self.addSwitch(PREFIX + str(x)))
 
    	def createAggLayerSwitch(self,N):
        #logger.debug( "Create Agg Layer")
        	for x in range(0,self.iAggLayerSwitch):
            		PREFIX = "S_Agg"
            		if x >= int(10):
                		PREFIX = "S_Agg"
            		self.AggSwitchList.append(self.addSwitch(PREFIX + str(x)))
 
    	def createEdgeLayerSwitch(self,N):
        #logger.debug("Create Edge Layer")
        	for x in range(0,self.iEdgeLayerSwitch):
            		PREFIX = "TOR"
            		if x >= int(10):
                		PREFIX = "TOR"
            		self.TORSwitchList.append(self.addSwitch(PREFIX + str(x)))
    
    	def createHost(self,N):
        #logger.debug("Create Host")
        	for x in range(0,self.iHost):
            		PREFIX = "Host"
            		if x >= int(10):
                		PREFIX = "Host"
            		self.HostList.append(self.addHost(PREFIX + str(x)))

	def createExtra(self,N):
        #logger.debug("Create Host")
        	for x in range(0,self.extra):
            		PREFIX = "eH"
            		if x >= int(10):
                		PREFIX = "eH"
            		self.ExList.append(self.addHost(PREFIX + str(x)))

	
	def createLink(self):
#creation of connections between core layer and aggregate layer
		self.addLink(self.CoreSwitchList[1], self.ExList[0])
		for x in range(0,self.A_AggLayerSwitch):
			if x % 2 == 0:
				self.addLink(self.CoreSwitchList[0], self.A_AggSwitchList[x])
				self.addLink(self.CoreSwitchList[2], self.A_AggSwitchList[x])
			else:
				self.addLink(self.CoreSwitchList[1], self.A_AggSwitchList[x])
				self.addLink(self.CoreSwitchList[3], self.A_AggSwitchList[x])
#creation of connections between aggregate layer 3 and layer 2
		
		for x in range(0,self.B_AggLayerSwitch):
			self.addLink(self.A_AggSwitchList[x], self.B_AggSwitchList[x])
		for x in range(0,1):
			self.addLink(self.A_AggSwitchList[x], self.B_AggSwitchList[x+1])
			self.addLink(self.A_AggSwitchList[x+1], self.B_AggSwitchList[x])
		for x in range(2,3):
			self.addLink(self.A_AggSwitchList[x], self.B_AggSwitchList[x+1])
			self.addLink(self.A_AggSwitchList[x+1], self.B_AggSwitchList[x])
		for x in range(4,5):
			self.addLink(self.A_AggSwitchList[x], self.B_AggSwitchList[x+1])
			self.addLink(self.A_AggSwitchList[x+1], self.B_AggSwitchList[x])
		for x in range(6,7):
			self.addLink(self.A_AggSwitchList[x], self.B_AggSwitchList[x+1])
			self.addLink(self.A_AggSwitchList[x+1], self.B_AggSwitchList[x])
		for x in range(8,9):
			self.addLink(self.A_AggSwitchList[x], self.B_AggSwitchList[x+1])
			self.addLink(self.A_AggSwitchList[x+1], self.B_AggSwitchList[x])
		for x in range(10,11):
			self.addLink(self.A_AggSwitchList[x], self.B_AggSwitchList[x+1])
			self.addLink(self.A_AggSwitchList[x+1], self.B_AggSwitchList[x])
		for x in range(12,13):
			self.addLink(self.A_AggSwitchList[x], self.B_AggSwitchList[x+1])
			self.addLink(self.A_AggSwitchList[x+1], self.B_AggSwitchList[x])
		for x in range(14,15):
			self.addLink(self.A_AggSwitchList[x], self.B_AggSwitchList[x+1])
			self.addLink(self.A_AggSwitchList[x+1], self.B_AggSwitchList[x])
		

#creation of connections between aggregate layer 2 and aggregate layer

		for x in range(0,self.iAggLayerSwitch):
			self.addLink(self.B_AggSwitchList[x], self.AggSwitchList[x])
		for x in range(0,1):
			self.addLink(self.B_AggSwitchList[x], self.AggSwitchList[x+1])
			self.addLink(self.B_AggSwitchList[x+1], self.AggSwitchList[x])
		for x in range(2,3):
			self.addLink(self.B_AggSwitchList[x], self.AggSwitchList[x+1])
			self.addLink(self.B_AggSwitchList[x+1], self.AggSwitchList[x])
		for x in range(4,5):
			self.addLink(self.B_AggSwitchList[x], self.AggSwitchList[x+1])
			self.addLink(self.B_AggSwitchList[x+1], self.AggSwitchList[x])
		for x in range(6,7):
			self.addLink(self.B_AggSwitchList[x], self.AggSwitchList[x+1])
			self.addLink(self.B_AggSwitchList[x+1], self.AggSwitchList[x])
		for x in range(8,9):
			self.addLink(self.B_AggSwitchList[x], self.AggSwitchList[x+1])
			self.addLink(self.B_AggSwitchList[x+1], self.AggSwitchList[x])
		for x in range(10,11):
			self.addLink(self.B_AggSwitchList[x], self.AggSwitchList[x+1])
			self.addLink(self.B_AggSwitchList[x+1], self.AggSwitchList[x])
		for x in range(12,13):
			self.addLink(self.B_AggSwitchList[x], self.AggSwitchList[x+1])
			self.addLink(self.B_AggSwitchList[x+1], self.AggSwitchList[x])
		for x in range(14,15):
			self.addLink(self.B_AggSwitchList[x], self.AggSwitchList[x+1])
			self.addLink(self.B_AggSwitchList[x+1], self.AggSwitchList[x])

		

#creation of connections between aggregate layer and edge layer
	
		for x in range(0,self.iAggLayerSwitch):
			self.addLink(self.AggSwitchList[x], self.TORSwitchList[2*x])
			self.addLink(self.AggSwitchList[x], self.TORSwitchList[(2*x)+1])

#creation of connections between edge layer and hosts

		for x in range(0, self.iEdgeLayerSwitch):
			self.addLink(self.TORSwitchList[x], self.HostList[2*x])
			self.addLink(self.TORSwitchList[x], self.HostList[(2*x)+1])

			

def enableSTP():
    """
    //HATE: Dirty Code
    """
    for x in range(0,4):
        cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("CORE" + str(x))
        os.system(cmd)
        print cmd 
 
    for x in range(0,16):
        cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("S_Agg" + str(x))
        os.system(cmd)  
        print cmd 
        cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("S_Agg2" + str(x))
        os.system(cmd)
        print cmd
	cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("S_Agg3" + str(x))
        os.system(cmd)
        print cmd
    for x in range(0,32):
	cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("TOR" + str(x))
        os.system(cmd)
        print cmd


def createTopo():
    #logging.debug("LV1 Create HugeTopo")
    topo = MultiTopo()
    topo.createTopo() 
    topo.createLink() 
    
    #logging.debug("LV1 Start Mininet")
    CONTROLLER_IP = "127.0.0.1"
    CONTROLLER_PORT = 6633
    net = Mininet(topo=topo, link=TCLink)
    net.addController('controller',ip=CONTROLLER_IP,port=CONTROLLER_PORT)
    net.start()
 
    #logger.debug("LV1 dumpNode")
    enableSTP()
    dumpNodeConnections(net.hosts)
    
    #pingTest(net)
    #iperfTest(net, topo)
    
 
    CLI(net)
    #net.stop()





if __name__ == '__main__':
    setLogLevel('info')
    if os.getuid() != 0:
        logger.debug("You are NOT root")
    elif os.getuid() == 0:
        createTopo()








