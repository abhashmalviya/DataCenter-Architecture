from mininet.net import Mininet
from mininet.node import Controller, RemoteController
from mininet.cli import CLI
from mininet.log import setLogLevel, info
from mininet.link import Link, Intf, TCLink
from mininet.topo import Topo
from mininet.util import dumpNodeConnections
import logging
import os 


logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger( __name__ )

class MultiTopo(Topo):
#creating lists for each of the core,aggregate,edge swtiches and Hosts
	CoreSwitchList = []
	AggSwitchList = []
	TORSwitchList = []
	HostList = []
	ExList = []
#Assigning the number of switches at each level and the total number of hosts.
	def __init__(self):
		self.iCoreLayerSwitch = 8
        	self.iAggLayerSwitch = 16
        	self.iEdgeLayerSwitch = 32
        	self.iHost = 64
		self.extra = 1

		Topo.__init__(self)
#creating the topology with switches and hosts
	def createTopo(self):    
     		self.createCoreLayerSwitch(self.iCoreLayerSwitch)
# logger.debug("Start create Agg Layer Swich ")
        	self.createAggLayerSwitch(self.iAggLayerSwitch)
# logger.debug("Start create Edge Layer Swich ")
        	self.createEdgeLayerSwitch(self.iEdgeLayerSwitch)
# logger.debug("Start create Host")
        	self.createHost(self.iHost)
		self.createExtra(self.extra)
	def createCoreLayerSwitch(self,N):
#logger.debug("Create Core Layer")
        	for x in range(0,self.iCoreLayerSwitch):
            		PREFIX = "CORE"
            		if x >= int(10):
                		PREFIX = "CORE"
            		self.CoreSwitchList.append(self.addSwitch(PREFIX + str(x)))
	def createAggLayerSwitch(self,N):
#logger.debug( "Create Agg Layer")
        	for x in range(0,self.iAggLayerSwitch):
            		PREFIX = "S_Agg"
            		if x >= int(10):
                		PREFIX = "S_Agg"
            		self.AggSwitchList.append(self.addSwitch(PREFIX + str(x)))
 
    	def createEdgeLayerSwitch(self,N):
#logger.debug("Create Edge Layer")
        	for x in range(0,self.iEdgeLayerSwitch):
            		PREFIX = "TOR"
            		if x >= int(10):
                		PREFIX = "TOR"
            		self.TORSwitchList.append(self.addSwitch(PREFIX + str(x)))
    	def createHost(self,N):
#logger.debug("Create Host")
        	for x in range(0,self.iHost):
            		PREFIX = "Host"
            		if x >= int(10):
                		PREFIX = "Host"
            		self.HostList.append(self.addHost(PREFIX + str(x)))
	def createExtra(self,N):
#logger.debug("Create Host")
        	for x in range(0,self.extra):
            		PREFIX = "eH"
            		if x >= int(10):
                		PREFIX = "eH"
            		self.ExList.append(self.addHost(PREFIX + str(x)))
	def createLink(self):
#creation of connections between core layer and aggregate layer
		self.addLink(self.CoreSwitchList[1], self.ExList[0])
		for x in range(0,self.iCoreLayerSwitch):
			for y in range(0,self.iAggLayerSwitch):
				self.addLink(self.CoreSwitchList[x], self.AggSwitchList[y])
#creation of connections between aggregate layer and edge layer
		for x in range(0,self.iAggLayerSwitch):
			self.addLink(self.AggSwitchList[x], self.TORSwitchList[2*x])
			self.addLink(self.AggSwitchList[x], self.TORSwitchList[2*x+1])

#creation of connections between edge layer and hosts
		for x in range(0, self.iEdgeLayerSwitch):
			for y in range(0,self.iHost): 
				self.addLink(self.TORSwitchList[x], self.HostList[y])
				self.addLink(self.TORSwitchList[x], self.HostList[y])
#Enabling STP on th bridges to avoid loop back conditions.
def enableSTP():
    for x in range(0,8):
    	cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("CORE" + str(x))
        os.system(cmd)
        print cmd 
    for x in range(0,16):
 	cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("S_Agg" + str(x))
 	os.system(cmd)  
      	print cmd 
        cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("S_Agg2" + str(x))
       	os.system(cmd)
        print cmd
	cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("S_Agg3" + str(x))
        os.system(cmd)
        print cmd
    for x in range(0,32):
	cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("TOR" + str(x))
       	os.system(cmd)
        print cmd
def createTopo():
#logging.debug("LV1 Create HugeTopo")
    topo = MultiTopo()
    topo.createTopo() 
    topo.createLink() 
#logging.debug("LV1 Start Mininet")
    CONTROLLER_IP = "127.0.0.1"
    CONTROLLER_PORT = 6633
    net = Mininet(topo=topo, link=TCLink)
    net.addController('controller',ip=CONTROLLER_IP,port=CONTROLLER_PORT)
    net.start()
#logger.debug("LV1 dumpNode")
    enableSTP()
    dumpNodeConnections(net.hosts)
    
    CLI(net)
#main function pertaining to OS running behind python.
if __name__ == '__main__':
    setLogLevel('info')
    if os.getuid() != 0:
        logger.debug("You are NOT root")
    elif os.getuid() == 0:
        createTopo()








