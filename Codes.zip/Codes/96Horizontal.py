from mininet.net import Mininet
from mininet.node import Controller, RemoteController
from mininet.cli import CLI
from mininet.log import setLogLevel, info
from mininet.link import Link, Intf, TCLink
from mininet.topo import Topo
from mininet.util import dumpNodeConnections
import logging
import os 

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger( __name__ )
#creating lists for each of the core,aggregate,edge swtiches and Hosts
class MultiTopo(Topo):
	CoreSwitchList = []
	AggSwitchList = []
	TORSwitchList = []
	HostList = []
#Assigning the number of switches at each level and the total number of hosts.	
	def __init__(self):
		self.CoreLayerSwitch = 6
        	self.AggLayerSwitch = 24
        	self.EdgeLayerSwitch = 72
        	self.Host = 96

		Topo.__init__(self)
#creating the topology with switches and hosts
	def createTopo(self):    
     		self.createCoreLayerSwitch(self.CoreLayerSwitch)
# logger.debug("Start create Agg Layer Swich ")
        	self.createAggLayerSwitch(self.AggLayerSwitch)
# logger.debug("Start create Edge Layer Swich ")
        	self.createEdgeLayerSwitch(self.EdgeLayerSwitch)
# logger.debug("Start create Host")
        	self.createHost(self.Host)
	def createCoreLayerSwitch(self,N):
#logger.debug("Create Core Layer")
        	for x in range(0,self.CoreLayerSwitch):
            		PREFIX = "CORE"
            		if x >= int(10):
                		PREFIX = "CORE"
            		self.CoreSwitchList.append(self.addSwitch(PREFIX + str(x)))
	def createAggLayerSwitch(self,N):
#logger.debug( "Create Agg Layer")
        	for x in range(0,self.AggLayerSwitch):
            		PREFIX = "S_Agg"
            		if x >= int(10):
                		PREFIX = "S_Agg"
            		self.AggSwitchList.append(self.addSwitch(PREFIX + str(x)))
	def createEdgeLayerSwitch(self,N):
#logger.debug("Create Edge Layer")
        	for x in range(0,self.EdgeLayerSwitch):
            		PREFIX = "TOR"
            		if x >= int(10):
                		PREFIX = "TOR"
            		self.TORSwitchList.append(self.addSwitch(PREFIX + str(x)))
    	def createHost(self,N):
#logger.debug("Create Host")
        	for x in range(0,self.Host):
            		PREFIX = "Host"
            		if x >= int(10):
                		PREFIX = "Host"
            		self.HostList.append(self.addHost(PREFIX + str(x)))
	def createLink(self):
#creation of connections between core layer and aggregate layer
		for x in range(0,self.CoreLayerSwitch):
			#for y in range(0,self.AggLayerSwitch):
			self.addLink(self.CoreSwitchList[x], self.AggSwitchList[(2*x)])
			self.addLink(self.CoreSwitchList[x], self.AggSwitchList[(2*x)+1])
			
#creation of connections between aggregate layer and edge layer
		for x in range(0,self.AggLayerSwitch):
			for y in range(0,self.EdgeLayerSwitch):
				self.addLink(self.AggSwitchList[x], self.TORSwitchList[y])

#creation of connections between edge layer and hosts
		for x in range(0,12):
			self.addLink(self.TORSwitchList[x], self.HostList[x+2])
		for x in range(12,24):
			self.addLink(self.TORSwitchList[x], self.HostList[x+6])
		for x in range(24,36):
			self.addLink(self.TORSwitchList[x], self.HostList[x+10])
		for x in range(36,48):
			self.addLink(self.TORSwitchList[x], self.HostList[x+14])
		for x in range(48,60):
			self.addLink(self.TORSwitchList[x], self.HostList[x+18])
		for x in range(60,72):
			self.addLink(self.TORSwitchList[x], self.HostList[x+22])
		for x in range(0,2):
			self.addLink(self.TORSwitchList[0], self.HostList[x])
		for x in range(14,16):
			self.addLink(self.TORSwitchList[11], self.HostList[x])
		for x in range(16,18):
			self.addLink(self.TORSwitchList[12], self.HostList[x])
		for x in range(30,32):
			self.addLink(self.TORSwitchList[23], self.HostList[x])
		for x in range(32,34):
			self.addLink(self.TORSwitchList[24], self.HostList[x])
		for x in range(46,48):
			self.addLink(self.TORSwitchList[35], self.HostList[x])
		for x in range(48,50):
			self.addLink(self.TORSwitchList[36], self.HostList[x])
		for x in range(62,64):
			self.addLink(self.TORSwitchList[47], self.HostList[x])
		for x in range(64,66):
			self.addLink(self.TORSwitchList[48], self.HostList[x])
		for x in range(78,80):
			self.addLink(self.TORSwitchList[59], self.HostList[x])
		for x in range(80,82):
			self.addLink(self.TORSwitchList[60], self.HostList[x])
		for x in range(94,96):
			self.addLink(self.TORSwitchList[71], self.HostList[x])
			
#Enabling STP on th bridges to avoid loop back conditions.
def enableSTP():
    for x in range(0,24):
    	cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("S_Agg" + str(x))
        os.system(cmd)  
        print cmd 
    for x in range(0,48):
	cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("TOR" + str(x))
        os.system(cmd)
        print cmd
def createTopo():
#logging.debug("LV1 Create HugeTopo")
    topo = MultiTopo()
    topo.createTopo() 
    topo.createLink() 
#logging.debug("LV1 Start Mininet")
    CONTROLLER_IP = "127.0.0.1"
    CONTROLLER_PORT = 6633
    net = Mininet(topo=topo, link=TCLink)
    net.addController( 'controller',ip=CONTROLLER_IP,port=CONTROLLER_PORT)
    net.start()
#logger.debug("LV1 dumpNode")
    enableSTP()
    dumpNodeConnections(net.hosts)
    
    CLI(net)
#main function pertaining to OS running behind python.
if __name__ == '__main__':
    setLogLevel('info')
    if os.getuid() != 0:
        logger.debug("You are NOT root")
    elif os.getuid() == 0:
        createTopo()









