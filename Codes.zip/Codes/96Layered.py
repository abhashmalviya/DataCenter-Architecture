from mininet.net import Mininet
from mininet.node import Controller, RemoteController
from mininet.cli import CLI
from mininet.log import setLogLevel, info
from mininet.link import Link, Intf, TCLink
from mininet.topo import Topo
from mininet.util import dumpNodeConnections
import logging
import os 


logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger( __name__ )

#Creating a Class for Topology

class MultiTopo(Topo):				
	CoreSwitchList = []   			#Creating a List for Core Switches
	AggSwitchList = []			#Creating a List for Aggregate Switches
	A_AggSwitchList = []			#Creating a List for Layer 2 Aggregate 				
	TORSwitchList = []			#Creating a List for Top of Rack Switches
	HostList = []				#Creating a List for Hosts
	ExList = []				#Creating a List for Hosts at Core Layer

#Defining values for the variables to pass in the arguments
	
	def __init__(self):
		self.CoreLayerSwitch = 2	
        	self.A_AggLayerSwitch = 8
		#self.EAgg2LayerSwitch 
        	self.AggLayerSwitch = 8
        	self.EdgeLayerSwitch = 8
        	self.Host = 96
		self.extra = 1

		Topo.__init__(self)		#Initializing the Topo

	def createTopo(self):    		#Creating a function to create switches and Hosts
     
        	self.createCoreLayerSwitch(self.CoreLayerSwitch)
		self.createAAggLayerSwitch(self.A_AggLayerSwitch)
        	self.createAggLayerSwitch(self.AggLayerSwitch)
        	self.createEdgeLayerSwitch(self.EdgeLayerSwitch)
        	self.createHost(self.Host)
		self.createExtra(self.extra)

#Defining functions with arguments and appending them with respective Switch and Host List

	def createCoreLayerSwitch(self,N):
              	for x in range(0,self.CoreLayerSwitch):
            		PREFIX = "CORE"
            		if x >= int(10):
                		PREFIX = "CORE"
            		self.CoreSwitchList.append(self.addSwitch(PREFIX + str(x)))

    	def createAAggLayerSwitch(self,N):
		for x in range(0, self.A_AggLayerSwitch):
	   		PREFIX = "S_Agg1"
	   		if x >= int(10):
	       			PREFIX = "S_Agg1"
	  		self.A_AggSwitchList.append(self.addSwitch(PREFIX + str(x)))
 
    	def createAggLayerSwitch(self,N):
               	for x in range(0,self.AggLayerSwitch):
            		PREFIX = "S_Agg"
            		if x >= int(10):
                		PREFIX = "S_Agg"
            		self.AggSwitchList.append(self.addSwitch(PREFIX + str(x)))
 
    	def createEdgeLayerSwitch(self,N):
       
        	for x in range(0,self.EdgeLayerSwitch):
            		PREFIX = "TOR"
            		if x >= int(10):
                		PREFIX = "TOR"
            		self.TORSwitchList.append(self.addSwitch(PREFIX + str(x)))
    
    	def createHost(self,N):
       
        	for x in range(0,self.Host):
            		PREFIX = "Host"
            		if x >= int(10):
                		PREFIX = "Host"
            		self.HostList.append(self.addHost(PREFIX + str(x)))

	def createExtra(self,N):
       
        	for x in range(0,self.extra):
            		PREFIX = "eH"
            		if x >= int(10):
                		PREFIX = "eH"
            		self.ExList.append(self.addHost(PREFIX + str(x)))

#Function to create Links between the created switches and Hosts
	
	def createLink(self):

#Creation of connections between core layer and aggregate layer

		self.addLink(self.CoreSwitchList[1], self.ExList[0])
		for x in range(0,self.A_AggLayerSwitch):
			self.addLink(self.CoreSwitchList[0], self.A_AggSwitchList[x])
			self.addLink(self.CoreSwitchList[1], self.A_AggSwitchList[x])
			
#Creation of connections between aggregate layer 1 and aggregate layer
	
		for x in range(0,8):
			self.addLink(self.A_AggSwitchList[x], self.AggSwitchList[x])
		for x in range(0,1):
			self.addLink(self.A_AggSwitchList[x], self.AggSwitchList[x+1])
			self.addLink(self.A_AggSwitchList[x+1], self.AggSwitchList[x])
		for x in range(2,3):
			self.addLink(self.A_AggSwitchList[x], self.AggSwitchList[x+1])
			self.addLink(self.A_AggSwitchList[x+1], self.AggSwitchList[x])
		for x in range(4,5):
			self.addLink(self.A_AggSwitchList[x], self.AggSwitchList[x+1])
			self.addLink(self.A_AggSwitchList[x+1], self.AggSwitchList[x])
		for x in range(6,7):
			self.addLink(self.A_AggSwitchList[x], self.AggSwitchList[x+1])
			self.addLink(self.A_AggSwitchList[x+1], self.AggSwitchList[x])
			
#Creation of connection between aggregate layer and edge layer 
		for x in range(0,8):
			self.addLink(self.AggSwitchList[x], self.TORSwitchList[x])
					

#Creation of connections between edge layer and hosts

		for x in range(0,12):
			self.addLink(self.TORSwitchList[0], self.HostList[x])
		for x in range(12,24):
			self.addLink(self.TORSwitchList[1], self.HostList[x])
		for x in range(24,36):
			self.addLink(self.TORSwitchList[2], self.HostList[x])
		for x in range(36,48):
			self.addLink(self.TORSwitchList[3], self.HostList[x])
		for x in range(48,60):
			self.addLink(self.TORSwitchList[4], self.HostList[x])
		for x in range(60,72):
			self.addLink(self.TORSwitchList[5], self.HostList[x])
		for x in range(72,84):
			self.addLink(self.TORSwitchList[6], self.HostList[x])
		for x in range(84,96):
			self.addLink(self.TORSwitchList[7], self.HostList[x])		


#Defining Spanning Tree Protocol function to have a loop free environment			

def enableSTP(): 	#enabling STP on switches

    for x in range(0,2):
        cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("CORE" + str(x))
        os.system(cmd)
        print cmd 
 
    for x in range(0,8):
        cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("S_Agg" + str(x))
        os.system(cmd)  
        print cmd 
        cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("S_Agg2" + str(x))
        os.system(cmd)
        print cmd
    for x in range(0,8):
	cmd = "ovs-vsctl set Bridge %s stp_enable=true" % ("TOR" + str(x))
        os.system(cmd)
        print cmd


def createTopo():		
    topo = MultiTopo()			#assigning class to a variable
    topo.createTopo() 			#Calling function to create Switches and Hosts
    topo.createLink() 			#Calling function to create Links
    
    
    CONTROLLER_IP = "127.0.0.1"		#Assigning Controller IP
    CONTROLLER_PORT = 6633		#Assigning Controller Port
    net = Mininet(topo=topo, link=TCLink)	#Creates network emulation with hosts spawned in network namespaces
    net.addController( 'controller',ip=CONTROLLER_IP,port=CONTROLLER_PORT) #Creating a controller
    net.start()				#Creating network with Hosts and Switches
 
    
    enableSTP()				#Calling STP function
    dumpNodeConnections(net.hosts)	#Dump a list of known connections
    
   
 
    CLI(net)				# Command Line Interface to communicate with nodes
    





if __name__ == '__main__':		#Creating main function
    setLogLevel('info')
    if os.getuid() != 0:
        logger.debug("You are NOT root")
    elif os.getuid() == 0:
        createTopo()			#Calling main function








